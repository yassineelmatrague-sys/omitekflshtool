import React, { useState } from 'react';
import { 
  Download, 
  Cpu, 
  Zap, 
  ShieldCheck, 
  Layers, 
  HardDrive, 
  HelpCircle, 
  Terminal, 
  Languages, 
  Settings, 
  Monitor, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle, 
  AlertTriangle,
  RefreshCw,
  Clock,
  Heart
} from 'lucide-react';
import InteractiveSimulator from './components/InteractiveSimulator';
import { Language } from './types';

const logoImg = '/src/assets/images/omitek_logo_1784145292696.jpg';

export default function App() {
  const [lang, setLang] = useState<Language>('ar'); // Default to Arabic as requested
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'windows' | 'macos' | 'linux'>('windows');

  const toggleLanguage = () => {
    setLang(prev => prev === 'ar' ? 'en' : 'ar');
  };

  const handleDownloadTrigger = () => {
    setDownloadModalOpen(true);
  };

  // Translations content
  const t = {
    navBrand: 'OMITEK FLASH TOOL',
    navSubtitle: 'MTK EDITION',
    navHome: lang === 'ar' ? 'الرئيسية' : 'Home',
    navFeatures: lang === 'ar' ? 'المميزات' : 'Features',
    navSimulator: lang === 'ar' ? 'المحاكي التفاعلي' : 'Interactive Demo',
    navRequirements: lang === 'ar' ? 'المتطلبات والتشغيل' : 'Requirements',
    navDownload: lang === 'ar' ? 'تحميل الأداة' : 'Download Now',

    // Hero Translation
    heroBadge: lang === 'ar' ? 'الإصدار الأحدث v3.21.0 مستقر وآمن' : 'LATEST RELEASE v3.21.0 - STABLE & SECURE',
    heroTitlePrefix: lang === 'ar' ? 'الأداة الأقوى لتفليش وإصلاح هواتف' : 'The Ultimate Tool for Flashing & Repairing',
    heroTitleSuffix: lang === 'ar' ? 'MediaTek (MTK)' : 'MediaTek (MTK) Devices',
    heroDesc: lang === 'ar' 
      ? 'أداة احترافية مخصصة لتفليش جميع الرومات الرسمية والمعدلة، وتخطي حماية حسابات جوجل (FRP)، وإصلاح السيريال، وفك البوتلودر للأجهزة التي تعمل بمعالجات ميديا تيك بكفاءة فائقة.' 
      : 'Professional utility for flashing official & custom stock ROMs, bypassing FRP locks, restoring network IMEI, and unlocking bootloaders with ultimate MTK high-speed BROM interface.',
    btnDownloadMain: lang === 'ar' ? 'تحميل مجاني الآن (رابط مباشر)' : 'Download Free Now (Direct Link)',
    btnTrySim: lang === 'ar' ? 'تجربة المحاكي التفاعلي' : 'Try Interactive Simulator',
    statSpeed: lang === 'ar' ? 'سرعة تفليش فائقة' : 'Ultra-Fast Flash',
    statDevices: lang === 'ar' ? 'دعم كامل لجميع الموديلات' : 'All MTK Chips Supported',
    statOffline: lang === 'ar' ? 'آمن ومحلي 100٪' : '100% Secure & Offline',

    // Features Section
    featuresTitle: lang === 'ar' ? 'المميزات الرئيسية والوظائف المتقدمة' : 'Key Features & Advanced Capabilities',
    featuresSubtitle: lang === 'ar' ? 'تم تصميم الأداة لتوفر للمطورين والمهندسين أقصى مرونة في التعامل مع المعالجات.' : 'Engineered to provide professional developers with complete lower-level firmware control.',
    
    feat1Title: lang === 'ar' ? 'كتابة وقراءة الرومات (Format / Read / Write)' : 'Read / Write Firmware / Format',
    feat1Desc: lang === 'ar' ? 'دعم قراءة رومات المصنع الرسمية وإعادة كتابتها وتنسيق الأقسام بشكل كامل وآمن.' : 'Easily backup stock partitions, write system firmware via scatter files, or format divisions securely.',
    
    feat2Title: lang === 'ar' ? 'تخطي حماية حساب جوجل (Erase FRP / Mi Account)' : 'Bypass FRP & Accounts',
    feat2Desc: lang === 'ar' ? 'حذف حماية حساب جوجل بنقرة واحدة، بالإضافة إلى إزالة قفل حساب شاومي (Mi Cloud) للأجهزة المدعومة.' : 'Instant bypass for Google Factory Reset Protection (FRP) and Mi Cloud locks in BROM handshaking.',
    
    feat3Title: lang === 'ar' ? 'فك وإغلاق البوتلودر (Unlock Bootloader)' : 'Unlock / Relock Bootloader',
    feat3Desc: lang === 'ar' ? 'فك حماية محمل الإقلاع لأجهزة ميديا تيك بضغطة زر مع الحفاظ على سلامة النظام.' : 'Instantly unlock or relock the bootloader with native partition patching on-the-fly.',
    
    feat4Title: lang === 'ar' ? 'إصلاح السيريال (IMEI Repair)' : 'IMEI / NVRAM Restore',
    feat4Desc: lang === 'ar' ? 'إصلاح وكتابة أرقام السيريال التالفة (IMEI) واستعادة شبكات الاتصال المفقودة عبر تعديل أقسام NVRAM/NVDATA.' : 'Rebuild broken radio interface partitions, patch IMEI, and restore NVRAM calibration tables.',
    
    feat5Title: lang === 'ar' ? 'تخطي حماية المعالج (Auth Bypass)' : 'Secure SLA/DA Auth Bypass',
    feat5Desc: lang === 'ar' ? 'تجاوز حماية المعالج الأساسية والاتصال المباشر عبر وضع BROM دون الحاجة إلى ملفات داونلود إيجنت معدلة.' : 'Bypass SLA/DA authentication protocols on MediaTek chips without expensive hardware dongles.',
    
    feat6Title: lang === 'ar' ? 'فحص واختبار الذاكرة (Memory Test)' : 'Hardware Memory Testing',
    feat6Desc: lang === 'ar' ? 'إجراء فحوصات شاملة لذواكر الهواتف (DRAM, EMMC, LPDDR) للتحقق من سلامة اللوحة الأم وصلاحية التخزين.' : 'Run comprehensive byte tests on DRAM, eMMC, and LPDDR chips to isolate physical motherboard defects.',

    // Brands / Compatibility
    compatTitle: lang === 'ar' ? 'متوافق مع أشهر العلامات التجارية' : 'Compatible with Leading Brands',
    compatSubtitle: lang === 'ar' ? 'تدعم الأداة الهواتف التي تعمل بمعالجات MediaTek من الشركات التالية:' : 'Comprehensive support built natively for MTK silicon across global manufacturers:',

    // Requirements Section
    reqTitle: lang === 'ar' ? 'متطلبات التشغيل والتثبيت' : 'Technical Specifications & Drivers',
    reqSubtitle: lang === 'ar' ? 'يرجى اتباع الإرشادات لضمان اتصال الهاتف بالحاسوب بشكل سليم ودون أخطاء.' : 'Follow driver setup guidelines to establish a clean BROM connection with your PC.',
    reqStep1: lang === 'ar' ? '1. تثبيت تعريفات ميديا تيك الرسمية (MTK USB VCOM Drivers).' : '1. Install Official MTK USB VCOM Drivers on your system.',
    reqStep2: lang === 'ar' ? '2. استخدام برنامج LibUSB لفلترة منفذ الـ USB لتجنب انقطاع التوصيل.' : '2. Run LibUSB Filter Wizard to route the MediaTek BROM port.',
    reqStep3: lang === 'ar' ? '3. استخدام كابل USB أصلي للتفليش (يفضل منفذ USB 2.0 خلفي).' : '3. Connect with a reliable high-quality USB 2.0 data cable.',
    reqSys: lang === 'ar' ? 'نظام التشغيل المدعوم: ويندوز 7 / 8 / 10 / 11 (64 بت)' : 'OS Requirements: Windows 7 / 8 / 10 / 11 (64-bit architecture)',

    // Download Table
    downloadTitle: lang === 'ar' ? 'مركز التحميل والملفات الرسمية' : 'Official Downloads Center',
    downloadDesc: lang === 'ar' ? 'اختر النسخة المناسبة لنظام تشغيلك. الملفات مرفوعة على خوادم سحابية سريعة ومحمية.' : 'Select the appropriate package for your system. Downloads are clean, zipped, and hosted on direct mirrors.',
    colFile: lang === 'ar' ? 'الملف والنسخة' : 'File & Version',
    colSize: lang === 'ar' ? 'الحجم' : 'File Size',
    colSystem: lang === 'ar' ? 'النظام' : 'Platform',
    colSha: 'SHA-256 Checksum',
    colAction: lang === 'ar' ? 'رابط التحميل' : 'Action Link',

    // Modal / Download Popup
    modalTitle: lang === 'ar' ? 'جاري تحضير رابط التحميل المباشر...' : 'Preparing Your Direct Download...',
    modalDesc: lang === 'ar' ? 'شكراً لثقتك بأداة Omitek Flash Tool. ملف التثبيت آمن وخالي من أي برمجيات ضارة.' : 'Thank you for choosing Omitek. Your package is compiled, scanned, and secure.',
    modalCounter: lang === 'ar' ? 'سيتم بدء التحميل تلقائياً خلال ثوانٍ...' : 'Your high-speed download will begin in a moment...',
    modalBtnForce: lang === 'ar' ? 'اضغط هنا لبدء التحميل فوراً' : 'Click here to download directly',
    modalWarning: lang === 'ar' ? 'يرجى إيقاف برنامج الحماية مؤقتاً أثناء التثبيت لتجنب حظر تعريفات منافذ BROM.' : 'Note: You might need to temporarily pause antivirus modules to allow custom LibUSB driver filtering.',

    // Footer
    footerSlogan: lang === 'ar' ? 'الأداة المتكاملة لتفليش وإصلاح هواتف MTK الذكية.' : 'The ultimate flashing toolkit for MediaTek devices.',
    footerCopyright: `© ${new Date().getFullYear()} Omitek Flash Tool. All rights reserved.`,
    footerPrivacy: lang === 'ar' ? 'تطبيق محلي آمن يعمل بنسبة 100٪ داخل بيئة نظامك.' : '100% Client-side safe. No user data telemetry collected.'
  };

  const downloads = [
    {
      name: 'Omitek_Flash_Tool_v3.21.0_Windows_Portable.zip',
      size: '142 MB',
      system: 'Windows (64-bit)',
      sha256: 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1f2'
    },
    {
      name: 'Omitek_Flash_Tool_v3.21.0_Windows_Installer.exe',
      size: '158 MB',
      system: 'Windows (64-bit)',
      sha256: '9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e'
    },
    {
      name: 'Omitek_MTK_USB_Drivers_v2.0.1.zip',
      size: '18 MB',
      system: 'Windows Driver Pack',
      sha256: '3a4b5c6d7e8f9a0b1c2d3e4f5g6h7i8j9k0l1m2n3o4p5q6r7s8t9u0v1w2x3y4z'
    }
  ];

  const brandList = [
    { name: 'Tecno', logo: '📱', desc: 'Spark, Camon, Phantom series' },
    { name: 'Infinix', logo: '⚡', desc: 'Hot, Note, Zero series' },
    { name: 'Realme', logo: '⭐', desc: 'C-series, Narzo, Realme Numeric' },
    { name: 'Xiaomi (Mi / Redmi)', logo: '🟠', desc: 'Redmi 9, 10, Note series MTK' },
    { name: 'Oppo', logo: '🟢', desc: 'A-series, Reno series' },
    { name: 'Vivo', logo: '🔵', desc: 'Y-series, V-series' },
    { name: 'Samsung', logo: '🌌', desc: 'Galaxy A03s, A12, A22 MTK series' }
  ];

  const scrollSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500/30 selection:text-indigo-200" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      
      {/* Dynamic Background Glowing Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none"></div>

      {/* Decorative lightning theme ambient overlays */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[300px] bg-indigo-500/10 rounded-full blur-[160px] pointer-events-none"></div>
      <div className="absolute top-[800px] left-10 w-[400px] h-[400px] bg-sky-500/5 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute bottom-[400px] right-10 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-[160px] pointer-events-none"></div>

      {/* Navigation Bar */}
      <nav className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-900 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="h-10 w-auto rounded-lg bg-slate-950 border border-slate-800 p-1 relative overflow-hidden flex items-center justify-center">
              <img 
                src={logoImg} 
                alt="Omitek Logo" 
                className="h-8 w-auto object-contain"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            </div>
            <div>
              <div className="flex items-center gap-1.5 font-display font-extrabold text-white text-base md:text-lg tracking-wide">
                <span>{t.navBrand}</span>
                <span className="text-xs bg-indigo-500/20 text-indigo-400 px-1.5 py-0.5 rounded font-mono font-semibold">{t.navSubtitle}</span>
              </div>
            </div>
          </div>

          {/* Quick Nav Anchors - Desktop */}
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
            <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="hover:text-white transition-all cursor-pointer">{t.navHome}</button>
            <button onClick={() => scrollSection('features')} className="hover:text-white transition-all cursor-pointer">{t.navFeatures}</button>
            <button onClick={() => scrollSection('simulator')} className="hover:text-white transition-all cursor-pointer">{t.navSimulator}</button>
            <button onClick={() => scrollSection('requirements')} className="hover:text-white transition-all cursor-pointer">{t.navRequirements}</button>
          </div>

          {/* Language Switch & Download Button */}
          <div className="flex items-center gap-3">
            
            {/* Bilingual Translation Trigger */}
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-800 transition-all font-mono cursor-pointer"
              title="Switch language / تغيير اللغة"
            >
              <Languages className="w-4 h-4 text-indigo-400" />
              <span>{lang === 'ar' ? 'English' : 'العربية'}</span>
            </button>

            {/* Direct Scroll to Download Button */}
            <button
              onClick={() => scrollSection('download')}
              className="hidden lg:flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-md shadow-indigo-900/30 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{t.navDownload}</span>
            </button>

          </div>

        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative pt-12 pb-20 px-4 max-w-7xl mx-auto text-center space-y-8">
        
        {/* Brand Logo Header Image */}
        <div className="max-w-xl mx-auto relative group mb-2">
          <div className="absolute -inset-1.5 bg-gradient-to-r from-indigo-500 via-sky-500 to-amber-500 rounded-3xl blur opacity-30 group-hover:opacity-40 transition duration-1000"></div>
          <div className="relative bg-slate-950 p-2 md:p-3 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
            <img 
              src={logoImg} 
              alt="Omitek Flash Tool Logo" 
              className="w-full h-auto object-cover rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Latest Version Ribbon Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold font-mono tracking-wider animate-fade-in">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          {t.heroBadge}
        </div>

        {/* Catchy Main Heading */}
        <div className="space-y-4 max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold font-display leading-[1.15] text-white tracking-tight">
            {t.heroTitlePrefix} <br className="hidden md:block"/>
            <span className="bg-gradient-to-r from-amber-400 via-indigo-400 to-sky-400 bg-clip-text text-transparent">
              {t.heroTitleSuffix}
            </span>
          </h1>
          <p className="text-slate-400 text-base sm:text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
            {t.heroDesc}
          </p>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto pt-4">
          <button
            onClick={handleDownloadTrigger}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm transition-all shadow-xl shadow-indigo-950/60 flex items-center justify-center gap-2.5 group cursor-pointer"
          >
            <Download className="w-5 h-5 text-yellow-300 group-hover:translate-y-0.5 transition-all" />
            <span>{t.btnDownloadMain}</span>
          </button>

          <button
            onClick={() => scrollSection('simulator')}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold text-sm transition-all border border-slate-800/80 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Terminal className="w-4 h-4 text-indigo-400" />
            <span>{t.btnTrySim}</span>
          </button>
        </div>

        {/* High-quality Stats highlights row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto pt-10 text-center">
          <div className="p-4 rounded-2xl bg-slate-900/40 border border-slate-900/60">
            <span className="text-xs text-slate-500 uppercase tracking-widest block font-mono mb-1">{t.statSpeed}</span>
            <span className="text-lg font-bold text-slate-200">BROM Port 42.8 MB/s</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/40 border border-slate-900/60">
            <span className="text-xs text-slate-500 uppercase tracking-widest block font-mono mb-1">{t.statDevices}</span>
            <span className="text-lg font-bold text-slate-200">MT65xx / MT67xx / MT68xx</span>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/40 border border-slate-900/60">
            <span className="text-xs text-slate-500 uppercase tracking-widest block font-mono mb-1">{t.statOffline}</span>
            <span className="text-lg font-bold text-slate-200">{lang === 'ar' ? 'الخصوصية التامة' : 'Local Sandbox'}</span>
          </div>
        </div>

        {/* Phone mockup styled overlay */}
        <div className="relative max-w-5xl mx-auto pt-12">
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent z-10"></div>
          
          {/* Neon bounding frame */}
          <div className="rounded-3xl border border-indigo-500/20 bg-slate-900/20 p-2 md:p-4 backdrop-blur-sm shadow-2xl">
            <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 aspect-[16/10] flex flex-col justify-between p-4 md:p-6 text-left relative">
              
              {/* Internal window representation */}
              <div className="flex items-center justify-between border-b border-slate-900 pb-3 mb-4 text-xs font-mono text-slate-500">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  <span className="ml-1 text-slate-400">OMITEK FLASH TOOL (MTK EDITION)</span>
                </div>
                <div className="bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded border border-indigo-500/20 text-[10px]">
                  MODE: PREMIUM
                </div>
              </div>

              {/* Layout Content mock preview */}
              <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-4 text-xs font-mono">
                
                {/* Left Panel */}
                <div className="md:col-span-4 p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
                  <span className="text-amber-400 font-bold block">CONNECTION STATE</span>
                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5 text-slate-400 text-[11px]">
                    <div>PORT: <span className="text-emerald-400 font-bold">COM4 (High Speed)</span></div>
                    <div>CHIP: <span className="text-white">MT6765 (Helio P35)</span></div>
                    <div>SRAM: <span className="text-indigo-300">384 KB</span></div>
                    <div>DRAM: <span className="text-indigo-300">3072 MB</span></div>
                  </div>
                </div>

                {/* Right Panel */}
                <div className="md:col-span-8 p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
                  <div className="space-y-2">
                    <span className="text-indigo-400 font-bold block">FIRMWARE FLASH LOGS</span>
                    <div className="bg-slate-950 rounded-lg p-3 text-[11px] text-slate-400 space-y-1 h-32 overflow-hidden border border-slate-800">
                      <div className="text-emerald-400">[OK] BROM protocol handshaking completed.</div>
                      <div className="text-emerald-400">[OK] DA loaded successfully. DRAM Configured.</div>
                      <div>[WRITE] partition [preloader] ... OK</div>
                      <div>[WRITE] partition [lk] ... OK</div>
                      <div className="text-amber-400 animate-pulse">[WRITE] partition [system] ... 48% (21.4 MB/s)</div>
                    </div>
                  </div>

                  <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800 mt-2">
                    <div className="w-[48%] h-full bg-gradient-to-r from-indigo-500 to-emerald-400"></div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>

      </header>

      {/* Simulator Section */}
      <section id="simulator" className="py-20 bg-slate-900/40 border-y border-slate-900 px-4 scroll-mt-20">
        <div className="max-w-7xl mx-auto">
          <InteractiveSimulator lang={lang} />
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-4 max-w-7xl mx-auto scroll-mt-20">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-16">
          <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest font-mono">
            {lang === 'ar' ? 'الوظائف والإمكانات' : 'UTILITIES SUMMARY'}
          </span>
          <h2 className="text-3xl md:text-4xl font-extrabold font-display text-white">
            {t.featuresTitle}
          </h2>
          <p className="text-slate-400 text-sm md:text-base">
            {t.featuresSubtitle}
          </p>
        </div>

        {/* Bento Grid Features Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Feature 1 */}
          <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-900 hover:border-indigo-500/20 transition-all duration-300 space-y-4">
            <div className="p-3 rounded-xl bg-indigo-500/10 text-indigo-400 w-fit">
              <Layers className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">{t.feat1Title}</h3>
            <p className="text-slate-400 text-sm leading-relaxed">{t.feat1Desc}</p>
          </div>

          {/* Feature 2 */}
          <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-900 hover:border-indigo-500/20 transition-all duration-300 space-y-4">
            <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 w-fit">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">{t.feat2Title}</h3>
            <p className="text-slate-400 text-sm leading-relaxed">{t.feat2Desc}</p>
          </div>

          {/* Feature 3 */}
          <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-900 hover:border-indigo-500/20 transition-all duration-300 space-y-4">
            <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 w-fit">
              <Cpu className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">{t.feat3Title}</h3>
            <p className="text-slate-400 text-sm leading-relaxed">{t.feat3Desc}</p>
          </div>

          {/* Feature 4 */}
          <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-900 hover:border-indigo-500/20 transition-all duration-300 space-y-4">
            <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 w-fit">
              <RefreshCw className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">{t.feat4Title}</h3>
            <p className="text-slate-400 text-sm leading-relaxed">{t.feat4Desc}</p>
          </div>

          {/* Feature 5 */}
          <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-900 hover:border-indigo-500/20 transition-all duration-300 space-y-4">
            <div className="p-3 rounded-xl bg-rose-500/10 text-rose-400 w-fit">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">{t.feat5Title}</h3>
            <p className="text-slate-400 text-sm leading-relaxed">{t.feat5Desc}</p>
          </div>

          {/* Feature 6 */}
          <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-900 hover:border-indigo-500/20 transition-all duration-300 space-y-4">
            <div className="p-3 rounded-xl bg-violet-500/10 text-violet-400 w-fit">
              <HardDrive className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">{t.feat6Title}</h3>
            <p className="text-slate-400 text-sm leading-relaxed">{t.feat6Desc}</p>
          </div>

        </div>
      </section>

      {/* Compatibility / Supported Brands Section */}
      <section className="py-20 bg-slate-900/20 border-t border-slate-900 px-4">
        <div className="max-w-7xl mx-auto space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <h2 className="text-3xl font-extrabold font-display text-white">
              {t.compatTitle}
            </h2>
            <p className="text-slate-400 text-sm sm:text-base">
              {t.compatSubtitle}
            </p>
          </div>

          {/* Horizontal Brand Scroll or grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
            {brandList.map((brand, idx) => (
              <div 
                key={idx}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-indigo-500/30 transition-all text-center space-y-2 flex flex-col justify-center items-center"
              >
                <span className="text-3xl">{brand.logo}</span>
                <span className="font-bold text-slate-200 text-sm font-display block">{brand.name}</span>
                <span className="text-[10px] text-slate-500 block leading-tight">{brand.desc}</span>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Requirements Section */}
      <section id="requirements" className="py-24 px-4 max-w-7xl mx-auto scroll-mt-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Instructions textual (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest font-mono">
                {lang === 'ar' ? 'دليل التهيئة والتشغيل السليم' : 'INSTALLATION SPECIFICATIONS'}
              </span>
              <h2 className="text-3xl md:text-4xl font-extrabold font-display text-white">
                {t.reqTitle}
              </h2>
              <p className="text-slate-400 text-sm leading-relaxed">
                {t.reqSubtitle}
              </p>
            </div>

            {/* List steps styled */}
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/60 flex items-start gap-3">
                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg shrink-0">
                  <Cpu className="w-5 h-5" />
                </div>
                <p className="text-slate-300 text-sm font-medium self-center">{t.reqStep1}</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/60 flex items-start gap-3">
                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg shrink-0">
                  <Settings className="w-5 h-5" />
                </div>
                <p className="text-slate-300 text-sm font-medium self-center">{t.reqStep2}</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/60 flex items-start gap-3">
                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg shrink-0">
                  <Zap className="w-5 h-5" />
                </div>
                <p className="text-slate-300 text-sm font-medium self-center">{t.reqStep3}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
              <Monitor className="w-4 h-4 text-indigo-500" />
              <span>{t.reqSys}</span>
            </div>
          </div>

          {/* Interactive Warning banner (5 cols) */}
          <div className="lg:col-span-5 p-6 rounded-3xl bg-slate-900/30 border border-slate-800 flex flex-col justify-between space-y-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none"></div>
            
            <div className="flex gap-3">
              <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl shrink-0 h-fit">
                <AlertTriangle className="w-6 h-6 animate-bounce" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-slate-200 font-display">
                  {lang === 'ar' ? 'تنبيه أمني هام للمطورين:' : 'Developer Note (Antivirus false positive):'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {lang === 'ar' 
                    ? 'نظراً لأن الأداة تقوم بالاتصال المباشر بمنافذ اللوحة الأم للهواتف وكتابة الرومات المنخفضة المستوى، قد تكتشف بعض برامج الحماية ملفات DLL كإيجابي خاطئ. الأداة آمنة تماماً ومضمونة 100٪.'
                    : 'Because our BROM custom filter DLLs write low-level partition blocks directly via kernel calls, some generic antivirus databases might trigger heuristic warning. This utility is 100% clean and virus-free.'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <span className="font-bold text-slate-400 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-indigo-400" />
                {lang === 'ar' ? 'سجل تحديثات v3.21.0' : 'What is New in v3.21.0'}
              </span>
              <ul className="list-disc list-inside space-y-1 text-slate-500 text-[11px] leading-relaxed">
                <li>{lang === 'ar' ? 'دعم كامل لمعالج Helio G96 و G99 الجديد.' : 'Added support for Helio G96 & G99 chips.'}</li>
                <li>{lang === 'ar' ? 'تحسين استقرار اتصال BROM دون بطارية.' : 'Improved offline BROM handshaking stability.'}</li>
                <li>{lang === 'ar' ? 'تحديث قاعدة بيانات تخطي حماية FRP لشهر يوليو 2026.' : 'Updated secure July 2026 security patch database.'}</li>
              </ul>
            </div>
          </div>

        </div>
      </section>

      {/* Downloads Official Table */}
      <section id="download" className="py-24 bg-slate-900/30 border-t border-slate-900 px-4 scroll-mt-20">
        <div className="max-w-7xl mx-auto space-y-10">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <h2 className="text-3xl font-extrabold font-display text-white">
              {t.downloadTitle}
            </h2>
            <p className="text-slate-400 text-sm">
              {t.downloadDesc}
            </p>
          </div>

          {/* Table list */}
          <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                <thead className="bg-slate-900 text-slate-400 text-xs font-mono uppercase border-b border-slate-800">
                  <tr>
                    <th scope="col" className="px-6 py-4">{t.colFile}</th>
                    <th scope="col" className="px-6 py-4">{t.colSize}</th>
                    <th scope="col" className="px-6 py-4">{t.colSystem}</th>
                    <th scope="col" className="px-6 py-4 hidden lg:table-cell">{t.colSha}</th>
                    <th scope="col" className="px-6 py-4 text-center">{t.colAction}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-900">
                  {downloads.map((dl, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/40 transition-colors">
                      <td className="px-6 py-4 font-semibold text-slate-200 font-mono">
                        {dl.name}
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-400">
                        {dl.size}
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 text-xs border border-indigo-500/20 font-medium">
                          {dl.system}
                        </span>
                      </td>
                      <td className="px-6 py-4 hidden lg:table-cell font-mono text-[10px] text-slate-500 truncate max-w-[200px]" title={dl.sha256}>
                        {dl.sha256}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={handleDownloadTrigger}
                          className="px-4 py-2 rounded-xl bg-indigo-600/10 hover:bg-indigo-600 text-indigo-400 hover:text-white border border-indigo-500/20 transition-all text-xs font-bold cursor-pointer"
                        >
                          {lang === 'ar' ? 'تنزيل الآن' : 'Download'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-12 px-4 mt-auto">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-300 animate-pulse" />
              <span className="font-display font-extrabold text-white text-lg">{t.navBrand}</span>
            </div>
            <p className="text-xs text-slate-500 max-w-sm">
              {t.footerSlogan}
            </p>
          </div>

          <div className="md:col-span-7 flex flex-col md:items-end space-y-2 text-xs text-slate-500">
            <span>{t.footerCopyright}</span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              {t.footerPrivacy}
            </span>
            <span className="flex items-center gap-1 text-[11px] text-slate-600 mt-2">
              Made with <Heart className="w-3 h-3 text-rose-500 fill-rose-500" /> for mobile hardware developers.
            </span>
          </div>

        </div>
      </footer>

      {/* Download Modal Trigger */}
      {downloadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-md p-6 bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl relative space-y-6 text-center animate-in zoom-in-95 duration-200">
            
            <div className="mx-auto p-4 bg-indigo-600/10 text-indigo-400 rounded-full w-fit animate-pulse">
              <Download className="w-8 h-8 text-yellow-300" />
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-bold font-display text-white">{t.modalTitle}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {t.modalDesc}
              </p>
            </div>

            {/* Simulated high-speed progress spinner */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-center gap-2 text-indigo-400 font-mono text-xs">
                <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                <span>{t.modalCounter}</span>
              </div>
              <p className="text-[10px] text-slate-500">
                Omitek_Flash_Tool_v3.21.0_Windows_Portable.zip (142 MB)
              </p>
            </div>

            {/* Antivirus Warning bar */}
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] flex gap-2 items-start text-left" dir="ltr">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <p className="leading-normal">{t.modalWarning}</p>
            </div>

            {/* CTA Trigger */}
            <div className="flex gap-3">
              <button
                onClick={() => {
                  // Simulate trigger click
                  window.location.href = 'https://github.com';
                }}
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm rounded-xl transition-all shadow-lg shadow-indigo-950/50 cursor-pointer"
              >
                {t.modalBtnForce}
              </button>
              <button
                onClick={() => setDownloadModalOpen(false)}
                className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm rounded-xl transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'إغلاق' : 'Close'}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
